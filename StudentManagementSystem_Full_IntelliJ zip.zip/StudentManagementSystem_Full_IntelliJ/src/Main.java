
import gui.Launcher;

public class Main {
    public static void main(String[] args) {
        Launcher.main(null);
    }
}
